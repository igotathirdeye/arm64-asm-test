export PKG_CONFIG_PATH=/usr/lib/aarch64-linux-gnu/pkgconfig:/usr/local/lib/aarch64-linux-gnu/pkgconfig

echo "Compiling C file..."
aarch64-linux-gnu-gcc -c main.c -o console.o \
    -I/usr/local/include \
    $(pkg-config --cflags sdl2)

echo "Linking..."
aarch64-linux-gnu-gcc -o console console.o \
    -L/usr/lib/aarch64-linux-gnu \
    $(pkg-config --libs sdl2) \
    -lGLESv2 \
    -lgbm \
    -ldrm \
    -lncursesw

rm console.o
echo "done"
qemu-aarch64 ./console