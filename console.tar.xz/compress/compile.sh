echo "compiling C file"
aarch64-linux-gnu-gcc -c main.c -o console.o \
    -I/usr/local/include \
    $(pkg-config --cflags sdl2)

echo "linking"
aarch64-linux-gnu-gcc -o console console.o \
    -L/usr/lib/aarch64-linux-gnu \
    -lncursesw \
    $(pkg-config --libs sdl2)

rm console.o
echo "done"
qemu-aarch64 ./console