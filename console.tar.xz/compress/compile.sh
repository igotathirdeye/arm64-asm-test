echo "compiling C file"
aarch64-linux-gnu-gcc -c main.c -o console.o \
    -I/usr/include \

echo "linking"
aarch64-linux-gnu-gcc -o console console.o \
    -L/usr/lib/aarch64-linux-gnu \
    -lncursesw

rm console.o
echo "done"
qemu-aarch64 ./console