export PKG_CONFIG_PATH=/usr/lib/aarch64-linux-gnu/pkgconfig:/usr/local/lib/aarch64-linux-gnu/pkgconfig

echo "Compiling C file..."
RAYLIB_PATH="/root/raylib/src"

aarch64-linux-gnu-gcc main.c -o console \
    -I$RAYLIB_PATH \
    -L$RAYLIB_PATH \
    -lraylib \
    -lGLESv2 \
    -lgbm \
    -ldrm \
    -lrt \
    -lm \
    -lpthread \
    -ldl

rm console.o
echo "done"
qemu-aarch64 ./console