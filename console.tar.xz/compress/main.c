#include <SDL2/SDL.h>
#include <SDL2/SDL_opencv.h> // Ignore if not needed, we use raw GLES2
#include <GLES2/gl2.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
    // Force KMSDRM driver
    SDL_setenv("SDL_VIDEODRIVER", "kmsdrm", 1);
    
    // Explicitly drop root requirements if you are testing locally
    SDL_SetHint(SDL_HINT_KMSDRM_REQUIRE_DRM_MASTER, "0"); 

    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        fprintf(stderr, "SDL_Init Error: %s\n", SDL_GetError());
        return 1;
    }

    printf("SUCCESS: Initialized Video using: %s\n", SDL_GetCurrentVideoDriver());

    // Request an OpenGLES 2.0 profile context 
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 2);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);

    // Create a mandatory full-screen canvas
    SDL_Window *window = SDL_CreateWindow("KMS Test", 
        SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 
        0, 0, SDL_WINDOW_FULLSCREEN_DESKTOP | SDL_WINDOW_OPENGL);

    if (!window) {
        fprintf(stderr, "Window Error: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_GLContext gl_context = SDL_GL_CreateContext(window);
    if (!gl_context) {
        fprintf(stderr, "GL Context Error: %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    printf("SUCCESS: Hardware surface context established!\n");

    // Loop for roughly 5 seconds flashing colors to prove video memory access works
    float r = 0.0f;
    for (int i = 0; i < 300; i++) {
        r += 0.01f;
        if (r > 1.0f) r = 0.0f;

        glClearColor(r, 0.2f, 0.4f, 1.0f); // Changing background color
        glClear(GL_COLOR_BUFFER_BIT);
        
        SDL_GL_SwapWindow(window); // Commit frame directly to DRM plane
        SDL_Delay(16); // ~60fps frame delays
    }

    printf("Test finished successfully. Cleaning up.\n");
    SDL_GL_DeleteContext(gl_context);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}