#include <ncurses.h>
#include "func.h"

int main() {
    initscr();
    start_color();
    
    init_pair(1, COLOR_WHITE, COLOR_BLUE);
    bkgd(COLOR_PAIR(1));
    init_color(8, 700, 700, 700);
    init_pair(2, COLOR_BLACK, 8);
    clear();

    int height = LINES * 0.75;
    int width = COLS * 0.75;
    int starty = (LINES - height) / 2;
    int startx = (COLS - width) / 2;
    attron(COLOR_PAIR(2));
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            mvaddch(starty + y, startx + x, ' ');
        }
    }

    mvprintw(LINES/2, COLS/2 - strlen("Hello!")/2, "Hello!");
    mvprintw(LINES/2+1, COLS/2 - strlen("This is a placeholder")/2, "This is a placeholder");
    refresh();
    getch();
    endwin();
    return 0;
}