#include "raylib.h"

int main(void) {
	// god fuck SDL, now i gotta learn how tf i use raylib
    InitWindow(0, 0, "raylib [core] - KMS/DRM Test");

    SetTargetFPS(60);

    Camera3D camera = { 0 };
    camera.position = (Vector3){ 0.0f, 10.0f, 10.0f };
    camera.target = (Vector3){ 0.0f, 0.0f, 0.0f };
    camera.up = (Vector3){ 0.0f, 1.0f, 0.0f };
    camera.fovy = 45.0f;
    camera.projection = CAMERA_PERSPECTIVE;

    while (!WindowShouldClose()) {
		// spinny spinny
        UpdateCamera(&camera, CAMERA_ORBITAL);

        BeginDrawing();

            ClearBackground(RAYWHITE);

            BeginMode3D(camera);
                DrawGrid(10, 1.0f);
                DrawCube((Vector3){ 0.0f, 1.0f, 0.0f }, 2.0f, 2.0f, 2.0f, RED);
                DrawCubeWires((Vector3){ 0.0f, 1.0f, 0.0f }, 2.0f, 2.0f, 2.0f, MAROON);
            EndMode3D();

            DrawFPS(10, 10);
            DrawText("SUCCESS: raylib running over KMS/DRM!", 10, 40, 20, DARKGRAY);

        EndDrawing();
    }

    // oh wow this really is kinda easy
    CloseWindow();

    return 0;
}